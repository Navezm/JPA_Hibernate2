create procedure getone(id integer)
    language sql
as
$$
SELECT student_id, first_name, last_name, birth_date, login, s.section_id, s.section_name, s.delegate_id, year_result, course_id, locality 
	FROM student 
	JOIN section s ON student.section_id = s.section_id
	WHERE student_id = id

$$;

alter procedure getone(integer) owner to postgres;


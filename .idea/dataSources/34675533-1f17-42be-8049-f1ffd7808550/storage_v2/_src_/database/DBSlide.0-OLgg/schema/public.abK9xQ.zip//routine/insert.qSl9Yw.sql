create procedure insert(id integer, firstname character varying, lastname character varying, birth timestamp without time zone, login character varying, sectionid integer, yearresult integer, courseid character varying, locality character varying)
    language sql
as
$$
INSERT INTO student VALUES (id, firstName, lastName, birth, login, sectionId, yearResult, courseId, locality)

$$;

alter procedure insert(integer, varchar, varchar, timestamp, varchar, integer, integer, varchar, varchar) owner to postgres;


create procedure delete(id integer)
    language sql
as
$$
DELETE FROM student WHERE student_id = id

$$;

alter procedure delete(integer) owner to postgres;

